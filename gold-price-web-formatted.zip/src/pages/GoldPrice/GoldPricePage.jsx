import React, { useEffect, useMemo, useState } from "react";
import { companyApi } from "../../api/companyApi";
import { goldPriceApi } from "../../api/goldPriceApi";
import { useAsync } from "../../hooks/useAsync";
import { useGoldPrices } from "../../hooks/useGoldPrices";
import Loading from "../../components/Loading/Loading";
import PriceTable from "../../components/PriceTable/PriceTable";
import "./GoldPricePage.css";
const PAGE_SIZE = 10;
export default function GoldPricePage({ initialCompanyId }) {
  const [companyId, setCompanyId] = useState(initialCompanyId ? String(initialCompanyId) : "all");
  const [keyword, setKeyword] = useState("");
  const [page, setPage] = useState(1);
  const [syncing, setSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState("");
  const companies = useAsync(() => companyApi.getAll(), []);
  const prices = useGoldPrices({ companyId, keyword });
  useEffect(() => {
    if (initialCompanyId) {
      setCompanyId(String(initialCompanyId));
      setPage(1);
    }
  }, [initialCompanyId]);
  const allItems = prices.data?.items || [];
  const totalItems = allItems.length;
  const totalPages = Math.ceil(totalItems / PAGE_SIZE);
  const pagedItems = useMemo(
    () => allItems.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    [allItems, page]
  );
  const selectedCompany = companies.data?.find((i) => String(i.id) === String(companyId));
  const handleSyncAll = async () => {
    setSyncing(true);
    setSyncMessage("");
    try {
      const r = await goldPriceApi.syncAllCompany();
      setSyncMessage(r.response_object.message);
      prices.refetch();
    } finally {
      setSyncing(false);
    }
  };
  const handleSyncCompany = async () => {
    if (companyId === "all") {
      setSyncMessage("Vui lòng chọn một hãng cụ thể để đồng bộ.");
      return;
    }
    setSyncing(true);
    setSyncMessage("");
    try {
      const r = await goldPriceApi.syncCompany(companyId);
      setSyncMessage(r.response_object.message);
      prices.refetch();
    } finally {
      setSyncing(false);
    }
  };
  if (companies.loading) return <Loading />;
  return (
    <main className="price-page">
      <div className="price-page-title">
        <h2>
          {selectedCompany ? `Bảng giá vàng ${selectedCompany.code}` : "Bảng giá vàng hôm nay"}
        </h2>
        <span />
      </div>
      <div className="price-filter-bar">
        <select
          value={companyId}
          onChange={(e) => {
            setCompanyId(e.target.value);
            setPage(1);
          }}
        >
          <option value="all">Tất cả công ty</option>
          {companies.data.map((c) => (
            <option key={c.id} value={c.id}>
              {c.code} - {c.name}
            </option>
          ))}
        </select>
        <input
          value={keyword}
          onChange={(e) => {
            setKeyword(e.target.value);
            setPage(1);
          }}
          placeholder="Tìm theo tên vàng, công ty, khu vực..."
        />
        <button onClick={handleSyncCompany} disabled={syncing}>
          {syncing ? "Đang đồng bộ..." : "Đồng bộ hãng"}
        </button>
        <button onClick={handleSyncAll} disabled={syncing}>
          Đồng bộ tất cả
        </button>
      </div>
      {syncMessage && <p className="sync-message">{syncMessage}</p>}
      {prices.loading ? (
        <Loading text="Đang tải bảng giá..." />
      ) : (
        <>
          <div className="table-summary">
            Hiển thị {pagedItems.length} / {totalItems} dòng dữ liệu
          </div>
          <PriceTable prices={pagedItems} />
          {totalPages > 1 && (
            <div className="pagination">
              <button disabled={page === 1} onClick={() => setPage(page - 1)}>
                ←
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  className={page === p ? "page-active" : ""}
                  onClick={() => setPage(p)}
                >
                  {p}
                </button>
              ))}
              <button disabled={page === totalPages} onClick={() => setPage(page + 1)}>
                →
              </button>
            </div>
          )}
        </>
      )}
    </main>
  );
}
