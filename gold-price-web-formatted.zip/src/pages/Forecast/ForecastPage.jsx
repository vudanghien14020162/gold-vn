import React from "react";
import { forecastApi } from "../../api/forecastApi";
import { useAsync } from "../../hooks/useAsync";
import Loading from "../../components/Loading/Loading";
import { formatChange, formatCurrency } from "../../utils/formatCurrency";
import "./ForecastPage.css";
export default function ForecastPage() {
  const f = useAsync(() => forecastApi.getForecast(), []);
  if (f.loading) return <Loading />;
  return (
    <main className="forecast-page">
      <h2>Dự đoán giá vàng SJC ngày mai</h2>
      <section className="panel forecast-page-card">
        <span>SJC • Hà Nội</span>
        <h3>Ngày dự đoán: {f.data.date}</h3>
        <div className="forecast-page-grid">
          <div>
            <p>Giá mua dự kiến</p>
            <strong className="price-green">{formatCurrency(f.data.buy)}</strong>
            <small className="text-green">{formatChange(f.data.buyChange)}</small>
          </div>
          <div>
            <p>Giá bán dự kiến</p>
            <strong className="price-gold">{formatCurrency(f.data.sell)}</strong>
            <small className="text-red">{formatChange(f.data.sellChange)}</small>
          </div>
        </div>
        <p className="forecast-note">{f.data.note}</p>
      </section>
    </main>
  );
}
