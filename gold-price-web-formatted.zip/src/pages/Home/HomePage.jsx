import React from "react";
import { homeApi } from "../../api/homeApi";
import { forecastApi } from "../../api/forecastApi";
import { useAsync } from "../../hooks/useAsync";
import GoldCard from "../../components/GoldCard/GoldCard";
import ChartBox from "../../components/ChartBox/ChartBox";
import Loading from "../../components/Loading/Loading";
import { formatChange, formatCurrency, getChangeClass } from "../../utils/formatCurrency";
import "./HomePage.css";
export default function HomePage({ onNavigate }) {
  const home = useAsync(() => homeApi.getHome(), []);
  const forecast = useAsync(() => forecastApi.getForecast(), []);
  if (home.loading || forecast.loading) return <Loading />;
  return (
    <>
      <section className="hero-section">
        <div className="gold-stack" aria-hidden="true">
          <span />
          <span />
          <span />
        </div>
        <div>
          <h1>
            {home.data.title}: {home.data.today}
          </h1>
          <p>{home.data.subtitle}</p>
          <small>Cập nhật: {home.data.updatedAt}</small>
        </div>
      </section>
      <main className="dashboard-layout">
        <section className="left-column">
          {home.data.featuredCompanies.map((company) => (
            <button
              type="button"
              key={company.id}
              className="company-card-button"
              onClick={() => onNavigate("price", { companyId: company.id })}
            >
              <GoldCard company={company} />
            </button>
          ))}
        </section>
        <section className="middle-column">
          <div className="section-title">
            <h2>Tổng quan thị trường</h2>
            <span />
          </div>
          <div className="panel market-box">
            <h3>Giá vàng nổi bật</h3>
            <div className="featured-list">
              {home.data.featuredCompanies.map((item) => (
                <article key={item.id} className="featured-item">
                  <div className="featured-header">
                    <div>
                      <strong>{item.code}</strong>
                      <span>{item.name}</span>
                    </div>
                    <span className={`featured-change ${getChangeClass(item.buyChange)}`}>
                      {formatChange(item.buyChange)}
                    </span>
                  </div>
                  <div className="featured-prices">
                    <div>
                      <label>Mua vào</label>
                      <p className="price-green">{formatCurrency(item.buy)}</p>
                    </div>
                    <div>
                      <label>Bán ra</label>
                      <p className="price-gold">{formatCurrency(item.sell)}</p>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            <button className="primary-action" onClick={() => onNavigate("price")}>
              Xem bảng giá chi tiết
            </button>
          </div>
        </section>
        <section className="right-column">
          <ChartBox />
          <div className="panel forecast-card">
            <div className="forecast-header">
              <div>
                <span className="forecast-badge">SJC • Hà Nội</span>
                <h3>Dự đoán giá vàng SJC ngày mai</h3>
                <p>Dự báo cho vàng miếng SJC khu vực Hà Nội</p>
              </div>
              <div className="forecast-confidence">
                <span>Độ tin cậy</span>
                <strong>{forecast.data.confidence}%</strong>
              </div>
            </div>
            <div className="forecast-grid">
              <div className="forecast-box buy">
                <span>▲ Giá mua dự kiến</span>
                <strong>{formatCurrency(forecast.data.buy)}</strong>
                <small className="text-green">{formatChange(forecast.data.buyChange)}</small>
              </div>
              <div className="forecast-box sell">
                <span>▼ Giá bán dự kiến</span>
                <strong>{formatCurrency(forecast.data.sell)}</strong>
                <small className="text-red">{formatChange(forecast.data.sellChange)}</small>
              </div>
            </div>
            <div className="forecast-footer">Dữ liệu dự báo từ lịch sử biến động giá vàng SJC.</div>
          </div>
        </section>
      </main>
    </>
  );
}
