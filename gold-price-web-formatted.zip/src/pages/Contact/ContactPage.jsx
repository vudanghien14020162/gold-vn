import React, { useState } from "react";
import "./ContactPage.css";
export default function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [success, setSuccess] = useState("");
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    setSuccess("Gửi liên hệ mock thành công.");
    setForm({ name: "", email: "", message: "" });
  };
  return (
    <main className="contact-page">
      <h2>Liên hệ</h2>
      <form className="panel contact-form" onSubmit={handleSubmit}>
        <label>
          Họ tên
          <input name="name" value={form.name} onChange={handleChange} required />
        </label>
        <label>
          Email
          <input name="email" value={form.email} onChange={handleChange} required />
        </label>
        <label>
          Nội dung
          <textarea name="message" value={form.message} onChange={handleChange} required />
        </label>
        <button type="submit">Gửi liên hệ</button>
        {success && <p>{success}</p>}
      </form>
    </main>
  );
}
