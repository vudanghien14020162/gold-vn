import React, { useEffect, useRef, useState } from "react";
import { ttsTelegramApi } from "../../api/ttsTelegramApi";
import Loading from "../../components/Loading/Loading";
import "./TtsTelegramPage.css";
export default function TtsTelegramPage() {
  const audioRef = useRef(null);
  const [companies, setCompanies] = useState([]);
  const [companyId, setCompanyId] = useState(1);
  const [audioInfo, setAudioInfo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState("");
  useEffect(() => {
    ttsTelegramApi.getCompanies().then((r) => setCompanies(r.response_object || []));
  }, []);
  const handleGenerateMp3 = async () => {
    setLoading(true);
    setMessage("");
    try {
      const r = await ttsTelegramApi.generateMp3(companyId);
      setAudioInfo(r.response_object);
      setMessage("Tạo MP3 mock thành công.");
      setTimeout(() => audioRef.current?.load(), 100);
    } finally {
      setLoading(false);
    }
  };
  const handleSendTelegram = async () => {
    if (!audioInfo) {
      setMessage("Bạn cần tạo MP3 trước khi gửi Telegram.");
      return;
    }
    setSending(true);
    setMessage("");
    try {
      const r = await ttsTelegramApi.sendToTelegram(audioInfo);
      setMessage(r.response_object.message);
    } finally {
      setSending(false);
    }
  };
  if (!companies.length) return <Loading />;
  return (
    <main className="tts-page">
      <h2>Đọc giá vàng & gửi MP3 Telegram</h2>
      <section className="panel tts-panel">
        <label>
          Chọn công ty
          <select value={companyId} onChange={(e) => setCompanyId(e.target.value)}>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {c.code} - {c.name}
              </option>
            ))}
          </select>
        </label>
        <div className="tts-actions">
          <button onClick={handleGenerateMp3} disabled={loading}>
            {loading ? "Đang tạo MP3..." : "Tạo MP3"}
          </button>
          <button onClick={handleSendTelegram} disabled={sending || !audioInfo}>
            {sending ? "Đang gửi..." : "Gửi Telegram"}
          </button>
        </div>
        {audioInfo && (
          <div className="tts-result">
            <h3>Thanh nghe MP3</h3>
            <audio ref={audioRef} controls preload="metadata">
              <source src={audioInfo.audioUrl} type="audio/mpeg" />
              Trình duyệt của bạn không hỗ trợ audio.
            </audio>
            <p>
              <strong>File:</strong> {audioInfo.fileName}
            </p>
            <div className="tts-text">{audioInfo.text}</div>
          </div>
        )}
        {message && <p className="tts-message">{message}</p>}
      </section>
    </main>
  );
}
