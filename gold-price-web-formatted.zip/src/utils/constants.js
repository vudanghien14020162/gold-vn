export const MENU_ITEMS = [
  { label: "Trang chủ", path: "home" },
  { label: "Bảng giá", path: "price" },
  { label: "Dự đoán", path: "forecast" },
  { label: "Đọc MP3", path: "tts" },
  { label: "Tin tức", path: "news" },
  { label: "Liên hệ", path: "contact" },
];
