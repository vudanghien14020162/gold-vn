import React from "react";
import { formatChange, formatCurrency, getChangeClass } from "../../utils/formatCurrency";
import "./PriceTable.css";
export default function PriceTable({ prices }) {
  if (!prices.length) return <div className="empty-card">Không có dữ liệu phù hợp.</div>;
  return (
    <div className="price-table">
      {prices.map((item) => (
        <article className="price-row" key={item.id}>
          <div>
            <h3>{item.name}</h3>
            <p>
              {item.company} - {item.area}
            </p>
          </div>
          <div className="price-col">
            <span>Mua</span>
            <strong>{formatCurrency(item.buy)}</strong>
            <small className={getChangeClass(item.buyChange)}>{formatChange(item.buyChange)}</small>
          </div>
          <div className="price-col">
            <span>Bán</span>
            <strong>{formatCurrency(item.sell)}</strong>
            <small className={getChangeClass(item.sellChange)}>
              {formatChange(item.sellChange)}
            </small>
          </div>
        </article>
      ))}
    </div>
  );
}
