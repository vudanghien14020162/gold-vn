import React, { useState } from "react";
import { goldMockData } from "../../data/goldMockData";
import { formatCurrency } from "../../utils/formatCurrency";
import "./ChartBox.css";
export default function ChartBox() {
  const [selectedDays, setSelectedDays] = useState(7);
  const [selectedPoint, setSelectedPoint] = useState(null);
  const data = goldMockData.sjcCharts[selectedDays];
  const latest = data[data.length - 1];
  const width = 360,
    height = 230,
    padding = 36;
  const values = data.flatMap((i) => [i.buy, i.sell]);
  const min = Math.min(...values) - 200000,
    max = Math.max(...values) + 200000;
  const getPoint = (item, key, index) => {
    const x = padding + (index * (width - padding * 2)) / (data.length - 1);
    const y = height - padding - ((item[key] - min) * (height - padding * 2)) / (max - min);
    return { x, y };
  };
  const buyPoints = data
    .map((item, i) => {
      const p = getPoint(item, "buy", i);
      return `${p.x},${p.y}`;
    })
    .join(" ");
  const sellPoints = data
    .map((item, i) => {
      const p = getPoint(item, "sell", i);
      return `${p.x},${p.y}`;
    })
    .join(" ");
  return (
    <section className="panel chart-box">
      <div className="chart-box-header">
        <div>
          <h3>Biểu đồ giá vàng</h3>
          <p>SJC vàng miếng - khu vực Hà Nội</p>
        </div>
        <div className="chart-current">
          <span>Giá bán hiện tại</span>
          <strong>{formatCurrency(latest.sell)}</strong>
        </div>
      </div>
      <div className="chart-tabs">
        {[7, 15, 30].map((days) => (
          <button
            key={days}
            type="button"
            className={selectedDays === days ? "active" : ""}
            onClick={() => {
              setSelectedDays(days);
              setSelectedPoint(null);
            }}
          >
            {days} ngày
          </button>
        ))}
      </div>
      <div className="chart-svg-wrap">
        <svg viewBox={`0 0 ${width} ${height}`} className="chart-svg">
          {[0, 1, 2, 3, 4].map((row) => (
            <line
              key={row}
              x1="24"
              x2="338"
              y1={34 + row * 38}
              y2={34 + row * 38}
              className="grid-line"
            />
          ))}
          <polyline points={buyPoints} className="line-buy" />
          <polyline points={sellPoints} className="line-sell" />
          {data.map((item, index) => {
            const buy = getPoint(item, "buy", index);
            const sell = getPoint(item, "sell", index);
            const showLabel = selectedDays === 7 || index % 3 === 0;
            return (
              <g key={`${item.date}-${index}`}>
                <circle
                  cx={buy.x}
                  cy={buy.y}
                  r="5"
                  className="dot-buy chart-click-dot"
                  onClick={() => setSelectedPoint(item)}
                />
                <circle
                  cx={sell.x}
                  cy={sell.y}
                  r="5"
                  className="dot-sell chart-click-dot"
                  onClick={() => setSelectedPoint(item)}
                />
                {showLabel && (
                  <text x={buy.x} y="220" textAnchor="middle" className="axis-label">
                    {item.date}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
        {selectedPoint && (
          <div className="chart-tooltip">
            <button type="button" onClick={() => setSelectedPoint(null)}>
              ×
            </button>
            <strong>{selectedPoint.date}</strong>
            <p>SJC vàng miếng - Hà Nội</p>
            <div>
              <span>Giá mua</span>
              <b>{formatCurrency(selectedPoint.buy)}</b>
            </div>
            <div>
              <span>Giá bán</span>
              <b>{formatCurrency(selectedPoint.sell)}</b>
            </div>
          </div>
        )}
      </div>
      <div className="chart-legend">
        <span className="legend-buy">Giá mua</span>
        <span className="legend-sell">Giá bán</span>
      </div>
    </section>
  );
}
