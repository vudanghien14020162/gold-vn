import React from "react";
import { Gem } from "lucide-react";
import { MENU_ITEMS } from "../../utils/constants";
import "./Header.css";
export default function Header({ activePage, onNavigate }) {
  return (
    <header className="header">
      <button className="brand-button" onClick={() => onNavigate("home")}>
        <span className="brand-icon">
          <Gem size={26} />
        </span>
        <span>GIÁ VÀNG</span>
      </button>
      <nav className="top-nav">
        {MENU_ITEMS.map((item) => (
          <button
            key={item.path}
            className={activePage === item.path ? "nav-active" : ""}
            onClick={() => onNavigate(item.path)}
          >
            {item.label}
          </button>
        ))}
      </nav>
      <button className="forecast-button" onClick={() => onNavigate("forecast")}>
        Dự đoán ngày mai
      </button>
    </header>
  );
}
