export function mockRequest(data, delay = 150) {
  return new Promise((resolve) =>
    setTimeout(() => resolve({ success: true, response_object: data }), delay)
  );
}
