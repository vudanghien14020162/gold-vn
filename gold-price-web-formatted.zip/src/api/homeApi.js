import { goldMockData } from "../data/goldMockData";
import { mockRequest } from "./mockClient";
export const homeApi = {
  getHome() {
    return mockRequest(goldMockData.home);
  },
};
