import { goldMockData } from "../data/goldMockData";
import { mockRequest } from "./mockClient";
export const goldPriceApi = {
  getAll(params = {}) {
    let items = [...goldMockData.prices];
    if (params.companyId && params.companyId !== "all")
      items = items.filter((i) => i.companyId === Number(params.companyId));
    if (params.keyword) {
      const k = params.keyword.toLowerCase();
      items = items.filter(
        (i) =>
          i.name.toLowerCase().includes(k) ||
          i.area.toLowerCase().includes(k) ||
          i.company.toLowerCase().includes(k)
      );
    }
    return mockRequest({ total: items.length, items });
  },
  syncAllCompany() {
    return mockRequest({
      message: "Đồng bộ tất cả công ty mock thành công",
      syncedAt: new Date().toLocaleString("vi-VN"),
    });
  },
  syncCompany(companyId) {
    const c = goldMockData.companies.find((i) => i.id === Number(companyId));
    return mockRequest({
      companyId: Number(companyId),
      companyName: c?.name || "Không xác định",
      message: `Đồng bộ ${c?.code || "công ty"} mock thành công`,
      syncedAt: new Date().toLocaleString("vi-VN"),
    });
  },
};
