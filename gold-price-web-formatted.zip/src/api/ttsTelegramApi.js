import { goldMockData } from "../data/goldMockData";
import { mockRequest } from "./mockClient";
const buildText = (companyId) =>
  goldMockData.prices
    .filter((i) => i.companyId === Number(companyId))
    .slice(0, 6)
    .map(
      (i) =>
        `${i.company}, ${i.name}, khu vực ${i.area}, mua vào ${i.buy.toLocaleString("vi-VN")} đồng, bán ra ${i.sell.toLocaleString("vi-VN")} đồng.`
    )
    .join(" ");
export const ttsTelegramApi = {
  getCompanies() {
    return mockRequest(goldMockData.companies);
  },
  generateMp3(companyId) {
    return mockRequest({
      id: Date.now(),
      companyId: Number(companyId),
      text: buildText(companyId),
      fileName: `gold-price-company-${companyId}.mp3`,
      audioUrl: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
      createdAt: new Date().toLocaleString("vi-VN"),
      status: "created",
    });
  },
  sendToTelegram(audioInfo) {
    return mockRequest({
      ...audioInfo,
      telegramStatus: "sent",
      message: "Đã gửi MP3 lên Telegram thành công bằng mock API.",
    });
  },
};
