import { goldMockData } from "../data/goldMockData";import { mockRequest } from "./mockClient";export const forecastApi={getForecast(){return mockRequest(goldMockData.forecast)}};
