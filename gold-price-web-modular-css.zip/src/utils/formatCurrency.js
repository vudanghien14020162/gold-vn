export function formatCurrency(value){if(value===null||value===undefined||Number.isNaN(Number(value)))return "-";return `${Number(value).toLocaleString("vi-VN")} đ`;}
export function formatChange(value){if(value===null||value===undefined||Number.isNaN(Number(value)))return "-";const sign=Number(value)>0?"+":"";return `${sign}${Number(value).toLocaleString("vi-VN")}`;}
export function getChangeClass(value){return Number(value)>=0?"text-green":"text-red";}
